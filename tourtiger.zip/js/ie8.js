$(document).ready(function() {

//$('.col-eq-height').matchHeight();
$('.col-eq-height').find('.title-excerpt').css('display','none');

});