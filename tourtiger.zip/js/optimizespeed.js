<script>
jQuery('img').each(function(){
jQuery(this).attr('width','auto');
jQuery(this).attr('height','auto');
})
</script>