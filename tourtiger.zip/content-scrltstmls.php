                <li class="t-slide slide">
                    <div class="txt-testimonial"><span class="name"><?php the_title(); ?>:</span> <?php the_field('testimonial_quote'); ?><div><a href="<?php echo esc_url( home_url() );?>/testimonials/" class="read-test">Read full Testimonial</a></div>
                    </div>
                </li>