<?php
    $integrate_xola = get_field('integrate_xola_with_this_website','option');
    $integrate_peek = get_field('integrate_peek_with_this_website','option');
    $integrate_fareharbor = get_field('fareharbor','option');
    $fareharbor_shortname = get_field('fareharbor_shortname','option');
    $integrate_getinsellout = get_field('getinsellout','option');
    $getinsellout_data_pn = get_field('getinsellout_data_pn','option');
    $getinsellout_data_url = get_field('getinsellout_data_url','option');
    $getinsellout_data_evt = get_field('getinsellout_data_evt','option');
    $integrate_trekksoft = get_field('trekksoft','option');
    $integrate_rezdy = get_field('rezdy','option');
    $integrate_zaui = get_field('zaui','option');
?>