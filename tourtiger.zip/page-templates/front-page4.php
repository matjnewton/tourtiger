<?php
/**
 * Template Name: Front-4 Page Template
 */

genesis();
