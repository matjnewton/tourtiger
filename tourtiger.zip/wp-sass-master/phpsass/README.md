#PHPSass [![build status](https://travis-ci.org/richthegeek/phpsass.png)](https://travis-ci.org/richthegeek/phpsass)

#IMPORTANT NOTICE
I'm not involved with PHP development anymore, and just don't have the time to do much more than approve pull requests for this project. I'm happy to stick around as a hands-off dictator, but if there are others who wish to take over maintainership then please get in touch ([my username]@gmail.com).

## About
This is fork of PHamlP primarily for inclusiong as a Drupal pre-processor.
However, there is no Drupal-specific code and it will work for any PHP system.

This version of the compiler is NOT compatible with other forks of PHamlP, and
the name has been changed to reflect this.

## Other info
Origin: <http://code.google.com/p/phamlp/>

License: <http://www.opensource.org/licenses/bsd-license.php>

