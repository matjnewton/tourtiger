	<form method="get" id="searchform" class="main-searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    		<input type="text" class="field" dir="auto" name="s" id="s" value="Search" />
    		<button class="submit btn btn-search glyphicon glyphicon-search" id="searchsubmit"></button>
                            </form>
